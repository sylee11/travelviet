git clone url project
In branch develop: git pull origin develop
git checkout feture/namnk/login
composer install
php artisan key:genegrate
Setting file .env
php artisan server