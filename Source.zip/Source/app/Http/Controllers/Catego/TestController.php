<?php

namespace App\Http\Controllers\Catego;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TestController extends Controller
{
    //
}
