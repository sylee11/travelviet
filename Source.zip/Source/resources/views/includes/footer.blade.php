<footer class="bg-dark" >
<!-- <<<<<<< HEAD
  <section id="main-footer" style="margin: 70px;" >
    <div class="container" style="display: flex; color: white;">
======= -->
  <section id="main-footer" style="margin-top: 40px; font-family: 'Raleway', sans-serif; 
 " >
    <div class="container row align-middle" style=" color: white; margin-top: 50px; margin-left: 7%;">

      <div class="col-sm-3" >
        <div style="margin-top: 40px;">
          <h3><span>TRAVEL&nbsp;</span><span class="footer-logo " style="color: #3997A6;">VIET</span></h3>
        </div>
        <div class="contactnumber">+84-345518122</div>

        <ul class="social list-inline">
          <li class="list-inline-item">
            <a href="https://www.facebook.com/"><i class="fab fa-facebook-square"></i></a>
          </li>
          <li class="list-inline-item">

            <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
          </li>
        </ul>
        <p class="copyright" style="color: white">&copy 2019 TRAVEL VIET</p><p class="copyright" style="color: white"> All rights reserved.</p>

      </div >
      <div class="col-sm-3 " style="margin-top: 50px;">
        <ul class="list_style">
          <li class="nav-head" style="margin-bottom: 30px;">US</li>
          <li><a href="" target="_blank" style="color: #3997A6;">About</a></li>
            <li><a href="" target="_blank" style="color: #3997A6;">Services</a></li>

        </ul>
      </div>
      <div class="col-sm-3 " style="margin-top: 50px;">
        <ul class="list_style">
          <li class="nav-head" style="margin-bottom: 30px;">TOUR AND BLOG</li>
          <li><a href="" target="_blank" style="color: #3997A6;">Our Top Tours</a></li>
          <li><a href="" target="_blank" style="color: #3997A6;">Blogs</a></li>
        </ul>
      </div>
      <div class="col-sm-3 " style="margin-top: 50px;">
        <ul class="list_style">
          <li class="nav-head" style="margin-bottom: 30px;">SUPPORT</li>
          <li><a href="" target="_blank" style="color: #3997A6;">Contact</a></li>
          <li><a href="" target="_blank" style="color: #3997A6;">Terms and Conditions</a></li>
        </ul>
      </div>
    </div>
  </div>
  </footer>
