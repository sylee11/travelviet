<div style="width: 100%; margin: 50px;" >
<div class="" style="display: flex; justify-content: center;">
	<img src="picture/logo.jpg" style="width: 120px; height: 120px; margin-right: 50px;">
	<div>
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="padding-top: 50px; color:blue;">
			  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			    <div class="navbar-nav">
			      <a class="nav-item nav-link " href="#" style="color: blue" >Trong nước  <span class="sr-only">(current)</span></a>
			      <a class="nav-item nav-link " style="color: blue" href="#">Ngoài nước </a>
			      <a class="nav-item nav-link" style="color: blue" href="#">Liên hệ</a>
			    </div>
			  </div>
		</nav>
	</div>
</div>
</div>