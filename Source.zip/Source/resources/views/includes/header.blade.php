<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
</head>
<body>
	<nav class="navbar navbar-expand-sm " style="background-color: #5f5f5f;">

	 	<!-- Links -->
	  	<ul class="navbar-nav" style="padding-left: 50px;">
		    <li class="nav-item">
		     	<a class="nav-link" href="#"><i class="fab fa-facebook-square" style= " "></i></a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="#"><i class="fab fa-twitter-square" style=""></i></a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="#"><i class="fab fa-youtube-square" style="color: red;"></i></a>
		    </li>
  		</ul>
  		<div class="d-flex flex-row-reverse" style="flex-direction: column-reverse; width: 100%; padding-right: 50px;" >
			<div class="p-2"><a href="" class="stretched-link" style="color: white; text-decoration: none;">Login</a> </div>
			<div class="p-2"><a href="" class="stretched-link" style="color: white; text-decoration: none; padding-right: 50px;">Register</a> </div>
		</div>
	</nav>
</body>
</html>


