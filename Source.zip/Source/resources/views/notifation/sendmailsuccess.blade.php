@extends('layouts.app')
@section('content')
	<div class="container" style="margin: 200px;">
		<h3 class=""> Send mail recovery success, Please check your email !! </h3>
	</div>
@endsection()